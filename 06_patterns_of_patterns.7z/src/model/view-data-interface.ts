export interface ViewDataInterface {
  cost: number;
  currency: string;
  disable: boolean;
  count: number;
  baseCost: number;
}