export interface CurrencyInterface {
  ccy: string;
  base_ccy: string;
  buy: number;
  sale: number;
}